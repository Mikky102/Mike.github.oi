
import { Component, ChangeDetectionStrategy, signal, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { ImageGenService } from './services/image-gen.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [ReactiveFormsModule],
  template: `
    <div class="min-h-screen bg-slate-950 text-slate-200 font-sans p-6 md:p-12">
      <div class="max-w-4xl mx-auto space-y-8">
        
        <!-- Header -->
        <header class="text-center space-y-2">
          <h1 class="text-4xl font-extrabold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
            Imagen AI Studio
          </h1>
          <p class="text-slate-400">Generate professional images with Google's Imagen model</p>
        </header>

        <!-- Control Panel -->
        <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
          <form [formGroup]="configForm" (ngSubmit)="onGenerate()" class="space-y-6">
            
            <!-- Prompt -->
            <div class="space-y-2">
              <label for="prompt" class="text-sm font-medium text-slate-300">Prompt Description</label>
              <textarea 
                id="prompt" 
                formControlName="prompt"
                rows="3"
                class="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white placeholder-slate-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all resize-none"
                [class.border-red-500]="configForm.get('prompt')?.touched && configForm.get('prompt')?.invalid"
                placeholder="A futuristic city with flying cars at sunset..."></textarea>
              @if (configForm.get('prompt')?.touched && configForm.get('prompt')?.invalid) {
                <div class="text-red-400 text-xs pl-1">
                  @if (configForm.get('prompt')?.hasError('required')) { Prompt is required. }
                  @if (configForm.get('prompt')?.hasError('minlength')) { Minimum 3 characters required. }
                </div>
              }
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
              <!-- Aspect Ratio -->
              <div class="space-y-2">
                <label for="aspectRatio" class="text-sm font-medium text-slate-300">Aspect Ratio</label>
                <select 
                  id="aspectRatio" 
                  formControlName="aspectRatio"
                  class="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:ring-2 focus:ring-blue-500 outline-none">
                  @for (ratio of aspectRatios; track ratio.value) {
                    <option [value]="ratio.value">{{ ratio.label }}</option>
                  }
                </select>
              </div>

              <!-- Count -->
              <div class="space-y-2">
                <label for="numberOfImages" class="text-sm font-medium text-slate-300">Number of Images</label>
                <select 
                  id="numberOfImages" 
                  formControlName="numberOfImages"
                  class="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:ring-2 focus:ring-blue-500 outline-none">
                  @for (count of imageCounts; track count) {
                    <option [ngValue]="count">{{ count }} {{ count === 1 ? 'Image' : 'Images' }}</option>
                  }
                </select>
              </div>
            </div>

            <!-- Generate Button -->
            <button 
              type="submit" 
              [disabled]="configForm.invalid || isLoading()"
              class="w-full bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-semibold py-4 rounded-xl transition-all shadow-lg hover:shadow-blue-500/25 flex items-center justify-center gap-2">
              @if (isLoading()) {
                <svg class="animate-spin h-5 w-5" viewBox="0 0 24 24">
                  <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" fill="none"></circle>
                  <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span>Generating...</span>
              } @else {
                <span>Generate Images</span>
              }
            </button>
          </form>
        </div>

        <!-- Error Banner -->
        @if (errorMessage()) {
          <div class="bg-red-950/50 border border-red-900/50 p-4 rounded-xl text-red-200 text-center">
            {{ errorMessage() }}
          </div>
        }

        <!-- Gallery -->
        @if (generatedImages().length) {
          <div class="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in duration-500">
            @for (img of generatedImages(); track $index) {
              <div class="group relative aspect-square bg-slate-900 rounded-xl overflow-hidden shadow-2xl">
                <img [src]="img" class="w-full h-full object-cover" [alt]="'Generated Image ' + ($index + 1)">
                <div class="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <button 
                    (click)="downloadImage(img, $index)"
                    class="bg-white/10 hover:bg-white/20 backdrop-blur-md text-white px-6 py-2 rounded-full font-medium transition-colors border border-white/10">
                    Download
                  </button>
                </div>
              </div>
            }
          </div>
        }
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppComponent {
  private fb: FormBuilder = inject(FormBuilder);
  private imageService = inject(ImageGenService);

  // Form configuration
  configForm = this.fb.group({
    prompt: ['', [Validators.required, Validators.minLength(3)]],
    aspectRatio: ['1:1', Validators.required],
    numberOfImages: [1, [Validators.required, Validators.min(1), Validators.max(4)]]
  });

  // State signals
  isLoading = signal(false);
  generatedImages = signal<string[]>([]);
  errorMessage = signal<string | null>(null);
  
  // Available options for the UI
  aspectRatios = [
    { value: '1:1', label: 'Square (1:1)' },
    { value: '16:9', label: 'Widescreen (16:9)' },
    { value: '9:16', label: 'Portrait (9:16)' },
    { value: '4:3', label: 'Landscape (4:3)' },
    { value: '3:4', label: 'Portrait (3:4)' }
  ];

  imageCounts = [1, 2, 3, 4];

  async onGenerate() {
    if (this.configForm.invalid || this.isLoading()) return;

    this.isLoading.set(true);
    this.errorMessage.set(null);
    this.generatedImages.set([]);

    try {
      const formVal = this.configForm.value;
      const prompt = formVal.prompt!;
      const aspectRatio = formVal.aspectRatio!;
      // FIX: Ensure numberOfImages is explicitly a number
      const numberOfImages = Number(formVal.numberOfImages);

      const response = await this.imageService.generateImages(
        prompt,
        aspectRatio,
        numberOfImages
      );

      if (response && response.generatedImages) {
        // Convert raw bytes to data URLs for display
        const images = response.generatedImages.map(
          (img: any) => `data:image/jpeg;base64,${img.image.imageBytes}`
        );
        this.generatedImages.set(images);
      } else {
        throw new Error('No images returned from the API.');
      }

    } catch (error: any) {
      console.error('Generation error:', error);
      let msg = 'Failed to generate images. Please try again.';
      if (error.message) {
        msg = `Error: ${error.message}`;
      }
      this.errorMessage.set(msg);
    } finally {
      this.isLoading.set(false);
    }
  }

  downloadImage(base64Url: string, index: number) {
    const link = document.createElement('a');
    link.href = base64Url;
    link.download = `imagine-ai-${Date.now()}-${index + 1}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}
