
import { Injectable } from '@angular/core';
import { GoogleGenAI } from '@google/genai';

@Injectable({
  providedIn: 'root'
})
export class ImageGenService {
  private ai: GoogleGenAI;

  constructor() {
    // Initialize the client with the API key from the environment
    this.ai = new GoogleGenAI({ apiKey: process.env['API_KEY'] });
  }

  /**
   * Generates images using the Imagen model.
   * @param prompt The text description of the image.
   * @param aspectRatio The desired aspect ratio (e.g., '1:1', '16:9').
   * @param numberOfImages Number of images to generate (1-4).
   */
  async generateImages(prompt: string, aspectRatio: string, numberOfImages: number) {
    // Call the generateImages API
    // Casting aspectRatio to any because strict string literal types in the SDK might conflict with general string input
    const response = await this.ai.models.generateImages({
      model: 'imagen-4.0-generate-001',
      prompt: prompt,
      config: {
        numberOfImages: Number(numberOfImages), // Explicit conversion to ensure it's a number
        outputMimeType: 'image/jpeg',
        aspectRatio: aspectRatio as any, 
      }
    });

    return response;
  }
}
